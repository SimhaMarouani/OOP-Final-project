#include "playersInclude/Simple.h"

Simple::Simple()
	:Players(Player::Simple)
{
}

Simple::Simple(sf::Vector2f position/*, Board& board*/)
	:Players(Player::Simple)
{}

