#include "TitledButton.h"


//TitledButton::TitledButton(sf::Vector2f size)
//	: m_button(size)
//{}
//
//void TitledButton::setText(std::string text)
//{
//	m_buttonText.setString(text);
//}
//
//void TitledButton::setPlayersText()
//{
//	m_buttonText.setFont(*Resources::instance().getFont());
//	m_buttonText.setCharacterSize(10);
//	m_buttonText.setPosition(100, 50);
//	m_buttonText.setColor(sf::Color::Black);
//	
//}
