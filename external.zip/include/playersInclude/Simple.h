#pragma once
#include "Players.h"
//#include "Board.h"

class Simple : public Players
{
public:
	Simple();
	Simple(sf::Vector2f position/*, Board& board*/);


	//void move(float deltaTime);

private:

};