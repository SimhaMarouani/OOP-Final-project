#pragma once
#include "Players.h"
//#include "Board.h"


class Heavy : public Players
{
public:
	Heavy();
	Heavy(sf::Vector2f position/*, Board& board*/);

	//void move(float deltaTime);

protected:

};

