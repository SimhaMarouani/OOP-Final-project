#pragma once
#include "StaticObjects.h"


class Box : public StaticObjects
{
public:
	Box();

private:

};