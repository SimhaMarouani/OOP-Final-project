#pragma once
#include "StaticObjects.h"


class Stairs : public StaticObjects
{
public:
	Stairs();

private:

};