#pragma once
#include "StaticObjects.h"


class Stick : public StaticObjects
{
public:
	Stick();

private:

};