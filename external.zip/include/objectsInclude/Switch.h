#pragma once
#include "StaticObjects.h"


class Switch : public StaticObjects
{
public:
	Switch();

private:

};