#pragma once
#include "Button.h"
#include "Resources.h"
#include <string>


class TitledButton : public Button
{
//public:
//	TitledButton(sf::Vector2f size);
//
//	void setText(std::string text);
//	void setPlayersText();
//
protected:
//	sf::Text m_buttonText;
//	Button m_button;
};

